
public interface Controle {
	void andar();
	void virar();
	void falar();

}
