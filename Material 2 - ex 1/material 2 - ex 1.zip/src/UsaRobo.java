
public class UsaRobo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Robo ro = new Robo();
		ro.andar();
		ro.falar();
		ro.virar();

	}

}
