
public class Robo implements Controle {

	@Override
	public void andar() {
		// TODO Auto-generated method stub
		System.out.println("Andando");
	}

	@Override
	public void virar() {
		// TODO Auto-generated method stub
		System.out.println("Virando");
	}

	@Override
	public void falar() {
		// TODO Auto-generated method stub
		System.out.println("Falando");
		
	}
	
	
	
}
